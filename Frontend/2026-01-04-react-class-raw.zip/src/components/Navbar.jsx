import { Link } from "wouter";
import { useAuth} from "../hooks/useAuth";

const Navbar = () => {
    const { isAuthenticated, logout } = useAuth();
    return (
        <nav className="bg-gray-800 text-white p-4 flex justify-between items-center w-[60vw]">
            <Link to="/" className="text-2xl font-bold">Home</Link>
            <Link to="/about" className="text-2xl font-bold">About</Link>
            {isAuthenticated ? 
            <Link className="text-2xl font-bold" onClick={logout}>Logout</Link> 
            : 
            <Link to="/login" className="text-2xl font-bold">Login</Link>}
        </nav>
    )
}

export default Navbar