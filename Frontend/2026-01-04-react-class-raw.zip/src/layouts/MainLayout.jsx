import Navbar from "../components/navbar";

function MainLayout({ children }) {
  return (
    <>
      <Navbar />
      <main className="p-4 bg-red-500 w-[60vw]">
        {children}
      </main>
    </>
  );
}

export default MainLayout;
