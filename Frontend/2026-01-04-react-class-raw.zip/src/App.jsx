import "./App.css";
import { Route } from "wouter";
import Home from "./pages/Home";
import About from "./pages/About";
import Login from "./pages/Login";
import MainLayout from "./layouts/MainLayout";
import { AuthProvider } from "./hooks/useAuth";

function App() {
  return (
    <AuthProvider >
      <MainLayout>
        <Route path="/" component={Home} />
        <Route path="/about" component={About} />
        <Route path="/login" component={Login} />
      </MainLayout>
    </AuthProvider>
  );
}

export default App;
