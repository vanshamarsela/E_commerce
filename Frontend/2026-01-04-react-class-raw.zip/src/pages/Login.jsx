import { useAuth } from "../hooks/useAuth";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
const Login = () => {
    const { login, isAuthenticated, user } = useAuth();

    const [location, setLocation] = useLocation();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const handleLogin = () => {
        login(username, password);
        console.log("location", location);
        setLocation("/");
    }

    useEffect(() => {
        if (isAuthenticated) {
            setLocation("/");
        }
    }, [isAuthenticated]);

    return (
        <div className="p-4 bg-gray-500 flex flex-col items-center justify-center gap-4 w-full h-full">
            <input type="text" placeholder="Username" className="p-2 rounded-md border-2 border-gray-300" value={username} onChange={(e) => setUsername(e.target.value)} />
            <input type="password" placeholder="Password" className="p-2 rounded-md border-2 border-gray-300" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button onClick={handleLogin}>Login</button>
            {isAuthenticated && <h1 className="text-2xl font-bold">Welcome {user?.username}</h1>}
        </div>
    )
}

export default Login