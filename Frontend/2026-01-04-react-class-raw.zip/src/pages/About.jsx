const About = () => {
  return (
    <div className="p-4 bg-blue-500">
      <h1 className="text-2xl font-bold">About with Navbar</h1>
    </div>
  )
}

export default About