import { useState, createContext, useContext, useEffect } from "react";


const AuthContext = createContext(null);

const AuthProvider = ({ children }) => {
    const authLogic = useAuthLogic();
    return (
        <AuthContext.Provider value={authLogic}>
            {children}
        </AuthContext.Provider>
    )
}

const useAuthLogic = () => {

    const [ isAuthenticated, setIsAuthenticated ] = useState(false);
    const [ user, setUser ] = useState(null);

    useEffect(() => {
        const isAuthenticated = localStorage.getItem("isAuthenticated");
        
        const user = localStorage.getItem("user");
        if (isAuthenticated) {
            setIsAuthenticated(true);
            setUser({ username: user });
        }
    }, []);

    const login = (username, password) => {
        console.log("login", username, password);
        setIsAuthenticated(true);
        localStorage.setItem("isAuthenticated", true);
        localStorage.setItem("user", username);
        setUser({ username });
    }

    const logout = () => {
        console.log("logout");
        setIsAuthenticated(false);
        setUser(null);
        localStorage.removeItem("isAuthenticated");
        localStorage.removeItem("user");
    }

    return {
        isAuthenticated,
        user,
        login,
        logout,
    }
}


const useAuth = () => {
    // return useAuthLogic();
    return useContext(AuthContext);
}


export { AuthProvider, useAuth };