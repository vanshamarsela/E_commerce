import "./App.css";
import { Route, Switch, useLocation } from "wouter";
import Home from "./pages/Home";
import About from "./pages/About";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import { ProductDetails } from "./pages/ProductDetails";
import MainLayout from "./layouts/MainLayout";
import AuthLayout from "./layouts/AuthLayout";
import { AuthProvider, useAuth } from "./hooks/useAuth";

// Protected Route Component
function ProtectedRoute({ children }) {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    setLocation("/login")
    return null;
  }

  return children;
}

// Public Route Component (redirects to home if already authenticated)
function PublicRoute({ children }) {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();


  if (isAuthenticated) {
    setLocation("/dashboard")
    return null;
  }

  return children;
}

function NotFound() {
  return (
    <MainLayout>
      <div className="text-center py-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">404</h1>
        <p className="text-gray-600 text-lg">Page not found</p>
      </div>
    </MainLayout>
  );
}



function App() {
  return (
    <AuthProvider>
      <Switch>
        {/* Protected Routes - require authentication */}
        <Route path="/">
          <MainLayout>
            <Home />
          </MainLayout>
        </Route>

        <Route path="/about">
          <MainLayout>
            <About />
          </MainLayout>
        </Route>

        <Route path="/products/:id">
         
          <MainLayout>
            <ProductDetails />
          </MainLayout>
        </Route>

        <Route path="/dashboard">
          <ProtectedRoute>
            <MainLayout>
              <Dashboard />
            </MainLayout>
          </ProtectedRoute>
        </Route>

        {/* Public Routes - accessible without authentication */}
        <Route path="/login">
          <PublicRoute>
            <AuthLayout>
              <Login />
            </AuthLayout>
          </PublicRoute>
        </Route>

        {/* 404 Route */}
        <Route path="*">
          <NotFound />
        </Route>
      </Switch>
    </AuthProvider>
  );
}

export default App;
