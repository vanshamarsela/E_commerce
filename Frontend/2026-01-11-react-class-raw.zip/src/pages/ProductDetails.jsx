
import { useEffect, useState } from "react";
import { dummyjson_api } from "../lib/api.js";
import { useParams } from "wouter";


export const ProductDetails = () => {

    const [id, setId] = useState(null);
    const params = useParams();
    const [product, setProduct] = useState(null)


    useEffect(() => {
        setId(params.id)
    }, [params])

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                let response = await dummyjson_api.get("/products/" + id);
                console.log(response.data)
                setProduct(response.data)
            } catch (err) {
                console.error(err)
            }
        }
        if (id) fetchProducts()
    }, [id])


    return (
        <>
            {product &&
                <div
                    key={product.id}
                    className="border rounded-lg p-4 shadow hover:shadow-lg transition"
                >
                    <img
                        src={product.images[0]}
                        alt={product.title}
                        className="h-200 w-full object-cover mb-3"
                    />

                    <h2 className="font-bold text-lg">{product.title}</h2>
                    <p className="text-sm text-gray-600 mb-2">
                        {product.description.slice(0, 80)}...
                    </p>

                    <p className="font-semibold text-green-600">
                        ${product.price}
                    </p>

                    <p className="text-sm text-gray-500">
                        Rating: ⭐ {product.rating}
                    </p>
                </div>
            }
        </>
    )
}
