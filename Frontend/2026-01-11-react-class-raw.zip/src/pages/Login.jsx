import { useAuth } from "../hooks/useAuth";
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
const Login = () => {
    const { login, isAuthenticated, user } = useAuth();

    const [location, setLocation] = useLocation();
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const [forwardTo, setForwardTo] = useState("/dashboard");

    useEffect(() => {
        setForwardTo("/about")
    }, [])

    const handleLogin = () => {
        login(username, password);
        console.log("location", location);
        setLocation(forwardTo);
    }

    useEffect(() => {
        if (isAuthenticated) {
            setLocation("/");
        }
    }, [isAuthenticated]);

    return (
        <>
        <div className="p-4 flex flex-col items-center justify-center gap-4 w-full h-full">
            <input type="text" placeholder="Username" className="p-2 w-full rounded-md text-gray-600 border-2 border-gray-300" value={username} onChange={(e) => setUsername(e.target.value)} />
            <input type="password" placeholder="Password" className="p-2 w-full rounded-md text-gray-600 border-2 border-gray-300" value={password} onChange={(e) => setPassword(e.target.value)} />
            <button onClick={handleLogin}>Login</button>
            {isAuthenticated && <h1 className="text-2xl font-bold">Welcome {user?.username}</h1>}
        </div>
        <Link to="/" >back</Link>

        </>
    )
}

export default Login