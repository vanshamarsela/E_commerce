import { dummyjson_api } from "../lib/api.js";
import { useState, useEffect } from "react";


const Dashboard = () => {
    const [count, setCount] = useState(0);
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                setLoading(true)
                let response = await dummyjson_api.get("/products");
                setProducts(response.data.products)
            } catch (err) {
                setError(err)
            } finally {
                setLoading(false)
            }
        }
        fetchProducts()
    }, [])

    return (
        <div className="py-12 px-6">
            <div className="text-center py-12">
                <h1 className="text-3xl font-bold text-gray-800 mb-4">Dashboard</h1>
                <p className="text-gray-600">Welcome to your dashboard!</p>

                <p className="text-black">Count : {count}</p>
                <button type="button" onClick={() => { console.log(count); setCount(count + 1) }}>Add</button>
            </div>

            {/* API States */}
            {loading && <p className="text-center text-blue-400">Loading products...</p>}
            {error && <p className="text-center text-red-500">{error}</p>}

            {/* Products List */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {products.map(product => (
                    <div
                        key={product.id}
                        className="border rounded-lg p-4 shadow hover:shadow-lg transition"
                    >
                        <img
                            src={product.thumbnail}
                            alt={product.title}
                            className="h-40 w-full object-cover mb-3"
                        />

                        <h2 className="font-bold text-lg">{product.title}</h2>
                        <p className="text-sm text-gray-600 mb-2">
                            {product.description.slice(0, 80)}...
                        </p>

                        <p className="font-semibold text-green-600">
                            ${product.price}
                        </p>

                        <p className="text-sm text-gray-500">
                            Rating: ⭐ {product.rating}
                        </p>
                    </div>
                ))}
            </div>
        </div>

    );
}

export default Dashboard