const Home = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Home with Navbar</h1>
    </div>
  )
}

export default Home