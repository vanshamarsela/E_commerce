import { Link } from "wouter";
import { useAuth } from "../hooks/useAuth";

const Navbar = () => {
    const { isAuthenticated, logout } = useAuth();
    return (
        <header>
            <div className="flex justify-between">
                <div>
                    <h2 className="text-blue-900">SHDPIXEL</h2>
                </div>
                <nav className="text-white p-4 flex gap-2 justify-between items-center">
                    <Link to="/" className="text-2xl font-bold">Home</Link>
                    <Link to="/about" className="text-2xl font-bold">About</Link>
                    <Link to="/dashboard" className="text-2xl font-bold">Dashboard</Link>

                    {
                        isAuthenticated ?
                            (
                                <>
                                    <Link className="text-2xl font-bold" onClick={logout}>Logout</Link>
                                </>
                            )
                            :
                            <Link to="/login?forward-to=/about" className="text-2xl font-bold">Login</Link>
                    }
                </nav>
            </div>

        </header>
    )
}

export default Navbar